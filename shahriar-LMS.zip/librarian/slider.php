		
    	<div style="overflow:hidden; width:960px; margin:0 auto; padding:0 20px;"> 
                <div class="pix_diapo">

                    <div data-thumb="../LMS/EB43.jpg">
                        <img src="../LMS/EB34.jpg">
                      
                    </div>
                    
                    <div data-thumb="../LMS/EB23.jpg">
                        <img src="../LMS/EB23.jpg"> 
                       
                    </div>
                    
                    <div data-thumb="../LMS/EB24.jpg" data-time="7000">
                        <img src="../LMS/EB24.jpg">
                    </div>
					
					<div data-thumb="../LMS/EB33.jpg" data-time="7000">
                        <img src="../LMS/EB33.jpg">
                    </div>
					
					<div data-thumb="../LMS/EB27.png" data-time="7000">
                        <img src="../LMS/EB27.png">
                    </div>
					
					<div data-thumb="../LMS/EB28.jpg" data-time="7000">
                        <img src="../LMS/EB28.jpg">
                    </div>
					
					<div data-thumb="../LMS/EB29.jpg" data-time="7000">
                        <img src="../LMS/EB29.jpg">
                    </div>
					
					<div data-thumb="../LMS/EB22.jpeg" data-time="7000">
                        <img src="../LMS/EB22.jpeg">
                    </div>
					
					<div data-thumb="../LMS/EB30.png" data-time="7000">
                        <img src="../LMS/EB30.png">
                    </div>
					<div data-thumb="../LMS/EB26.jpg" data-time="7000">
                        <img src="../LMS/EB26.jpg">
                    </div>
					
					<div data-thumb="../LMS/EB21.jpg" data-time="7000">
                        <img src="../LMS/EB21.jpg">
                    </div>
					
					<div data-thumb="../LMS/EB25.jpg" data-time="7000">
                        <img src="../LMS/EB25.jpg">
                    </div>
					
					<div data-thumb="../LMS/EB31.jpg" data-time="7000">
                        <img src="../LMS/EB31.jpg">
                    </div>
                    
      
                    
               </div><!-- #pix_diapo -->
                
        </div>
    
    
    </section> 