  		
	<?php include('tooltip.php'); ?>			
	<div class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="nav-collapse collapse">
					<ul class="nav">
				     <li>
					 <a  rel="tooltip"  data-placement="bottom" title="Home" id="home"   href="index.php">&nbsp;Home</a> 
					 </li>
				
					<li>
					<a rel="tooltip"  data-placement="bottom" title="Click Here to About" id="login" href="#">&nbsp;About</a> 
					</li>
					
					
					
					
					<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to Gallary" id="login" href="#">&nbsp;Gallary</a>
					</li>
		            <li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to Log Out" id="login" href="signout.php">&nbsp;LogOut</a>
					</li>
	
					
					</ul>

			

                    
						

                    </div>
                </div>
            </div>
        </div>
   

	     	