  		
	<?php include('tooltip.php'); ?>			
	<div class="navbar navbar-fixed-top navbar-inverse">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="nav-collapse collapse">
					<ul class="nav">
				     <li>
					 <a  rel="tooltip"  data-placement="bottom" title="Home" id="home"   href="dashboard.php">&nbsp;Home</a> 
					 </li>
				
					<li>
					<a rel="tooltip"  data-placement="bottom" title="Click Here to About" id="login" href="subadd.php">&nbsp;Add subject</a> 
					</li>
					
					<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to Admin" id="login" href="testadd.php">&nbsp;Add Test</a>
					</li>
					
					
					<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to Gallary" id="login" href="questionadd.php">&nbsp;Add Question</a>
					</li>
					<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to Gallary" id="login" href="signout.php">&nbsp;Log Out</a>
					</li>
	
					
					</ul>

			

                    
						

                    </div>
                </div>
            </div>
        </div>
   

	     	